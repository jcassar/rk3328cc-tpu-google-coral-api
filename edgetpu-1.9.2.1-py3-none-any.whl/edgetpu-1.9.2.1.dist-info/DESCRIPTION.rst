# Edge TPU Python API

This repository contains an easy-to-use Python API to work with Coral devices:

* [Dev Board](https://coral.withgoogle.com/products/dev-board/)
* [USB Accelerator](https://coral.withgoogle.com/products/accelerator/)

You can run inference and do transfer learning.


